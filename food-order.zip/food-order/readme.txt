Install XAMPP server first, then navigate to the installed directory.

The "htdocs" folder can be found there.

Paste the project folder within the "htdocs" folder (not the .zip one, but the extracted one).

Activate the Xampp control panel, then start Apache and MySQL.

Launch your browser.

Visit "http://localhost/phpmyadmin" after that.

Create a database called "food-order" in your system.

Choose the database file (food-order.sql) from the "Database File" folder by clicking on the "Import" tab.

Go to "http://localhost/food-order/" after configuring all of them.

Go to "http://localhost/admin" and enter the following user name and password to access the admin portal.

Login 
username: admin
password: admin